package com.alightfix.studio;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends Activity {

    private static final int REQ_PICK_FILE = 1001;
    private static final String ASSET_PREFIX = "file:///android_asset/";
    private static final int MAX_FETCH_BYTES = 4 * 1024 * 1024;
    private static final int MAX_SHARED_FILE_BYTES = 8 * 1024 * 1024;
    private static final String UA = "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 "
            + "(KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36";

    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private boolean pageReady = false;
    private final List<String> pendingJs = new ArrayList<>();
    private final Map<String, Object[]> uploads = new HashMap<>();

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().setStatusBarColor(Color.parseColor("#080D16"));
        getWindow().setNavigationBarColor(Color.parseColor("#080D16"));

        webView = new WebView(this);
        webView.setBackgroundColor(Color.parseColor("#080D16"));
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setUseWideViewPort(true);

        webView.addJavascriptInterface(new Bridge(), "AndroidBridge");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                if (url.startsWith(ASSET_PREFIX) || url.startsWith("about:") || url.startsWith("javascript:")) {
                    return false; // stay inside the app
                }
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, request.getUrl()));
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(MainActivity.this, "No app found to open this link", Toast.LENGTH_SHORT).show();
                }
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                pageReady = true;
                for (String js : pendingJs) {
                    view.evaluateJavascript(js, null);
                }
                pendingJs.clear();
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(null);
                }
                filePathCallback = callback;

                // Any file type: some file managers label .xml files as octet-stream
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                try {
                    startActivityForResult(Intent.createChooser(intent, "Select a file"), REQ_PICK_FILE);
                } catch (ActivityNotFoundException e) {
                    filePathCallback = null;
                    callback.onReceiveValue(null);
                    Toast.makeText(MainActivity.this, "No file picker available", Toast.LENGTH_SHORT).show();
                    return false;
                }
                return true;
            }
        });

        boolean restored = savedInstanceState != null && webView.restoreState(savedInstanceState) != null;
        if (!restored) {
            webView.loadUrl(ASSET_PREFIX + "index.html");
        }
        if (savedInstanceState == null) {
            handleIntent(getIntent());
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIntent(intent);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        webView.saveState(outState);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQ_PICK_FILE) {
            if (filePathCallback != null) {
                Uri[] result = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
                filePathCallback.onReceiveValue(result);
                filePathCallback = null;
            }
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onBackPressed() {
        // Let the page close a dialog or go back to the first tab; otherwise leave the app.
        webView.evaluateJavascript("(window.__handleBack && window.__handleBack()) ? '1' : '0'", value -> {
            if (!"\"1\"".equals(value)) {
                finish();
            }
        });
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.destroy();
        }
        super.onDestroy();
    }

    // ---------------------------------------------------------------- incoming shares

    private void runJs(final String js) {
        runOnUiThread(() -> {
            if (pageReady) {
                webView.evaluateJavascript(js, null);
            } else {
                pendingJs.add(js);
            }
        });
    }

    @SuppressWarnings("deprecation")
    private void handleIntent(Intent intent) {
        if (intent == null) {
            return;
        }
        String action = intent.getAction();
        try {
            if (Intent.ACTION_SEND.equals(action)) {
                Uri stream = Build.VERSION.SDK_INT >= 33
                        ? intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri.class)
                        : (Uri) intent.getParcelableExtra(Intent.EXTRA_STREAM);
                String text = intent.getStringExtra(Intent.EXTRA_TEXT);
                if (stream != null) {
                    deliverFile(stream);
                } else if (text != null) {
                    runJs(queueScript("{k:'text',v:" + JSONObject.quote(text) + "}"));
                }
            } else if (Intent.ACTION_VIEW.equals(action) && intent.getData() != null) {
                deliverFile(intent.getData());
            }
        } catch (Exception e) {
            Toast.makeText(this, "Could not open the shared item", Toast.LENGTH_SHORT).show();
        }
    }

    private static String queueScript(String item) {
        return "(window.__incomingQ=window.__incomingQ||[]).push(" + item + ");"
                + "if(window.__drainIncoming){window.__drainIncoming();}";
    }

    private void deliverFile(final Uri uri) {
        new Thread(() -> {
            try {
                String name = queryName(uri);
                byte[] data = readCapped(getContentResolver().openInputStream(uri), MAX_SHARED_FILE_BYTES);
                String b64 = Base64.encodeToString(data, Base64.NO_WRAP);
                runJs(queueScript("{k:'file',name:" + JSONObject.quote(name) + ",v:" + JSONObject.quote(b64) + "}"));
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this,
                        "Could not read that file (max 8 MB)", Toast.LENGTH_LONG).show());
            }
        }).start();
    }

    private String queryName(Uri uri) {
        String name = null;
        try (Cursor c = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                name = c.getString(0);
            }
        } catch (Exception ignored) {
            // fall through to default
        }
        return (name == null || name.isEmpty()) ? "shared.xml" : name;
    }

    private static byte[] readCapped(InputStream in, int max) throws IOException {
        if (in == null) {
            throw new IOException("No data");
        }
        try (InputStream src = in) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int total = 0;
            int n;
            while ((n = src.read(buf)) != -1) {
                total += n;
                if (total > max) {
                    throw new IOException("Too large");
                }
                out.write(buf, 0, n);
            }
            return out.toByteArray();
        }
    }

    // ---------------------------------------------------------------- saving

    private static String safeName(String filename, String fallback) {
        String safe = filename == null ? "" : filename.replaceAll("[\\\\/:*?\"<>|]", "_").trim();
        return safe.isEmpty() ? fallback : safe;
    }

    /** Writes text to Downloads/AlightFix and returns the content Uri. */
    private Uri saveToDownloads(String filename, String content) throws IOException {
        ContentValues values = new ContentValues();
        values.put(MediaStore.MediaColumns.DISPLAY_NAME, safeName(filename, "AlightFix.xml"));
        values.put(MediaStore.MediaColumns.MIME_TYPE, "text/xml");
        values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/AlightFix");

        ContentResolver resolver = getContentResolver();
        Uri uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
        if (uri == null) {
            throw new IOException("Could not create file");
        }
        try (OutputStream out = resolver.openOutputStream(uri)) {
            if (out == null) {
                throw new IOException("Could not open file");
            }
            out.write(content.getBytes(StandardCharsets.UTF_8));
        } catch (IOException e) {
            resolver.delete(uri, null, null);
            throw e;
        }
        return uri;
    }

    // ---------------------------------------------------------------- networking

    private static class Fetched {
        int status;
        String finalUrl;
        byte[] data;
    }

    /** https-only GET with manual redirects and a block on private/local addresses. */
    private Fetched fetch(String start) throws IOException {
        String current = start;
        for (int hop = 0; hop < 7; hop++) {
            URL u = new URL(current);
            if (!"https".equalsIgnoreCase(u.getProtocol())) {
                throw new IOException("Only https links are allowed");
            }
            for (InetAddress a : InetAddress.getAllByName(u.getHost())) {
                if (a.isAnyLocalAddress() || a.isLoopbackAddress() || a.isLinkLocalAddress() || a.isSiteLocalAddress()) {
                    throw new IOException("Blocked address");
                }
            }
            HttpURLConnection c = (HttpURLConnection) u.openConnection();
            c.setInstanceFollowRedirects(false);
            c.setConnectTimeout(12000);
            c.setReadTimeout(20000);
            c.setRequestProperty("User-Agent", UA);
            c.setRequestProperty("Accept-Language", "en-US,en;q=0.9");
            c.setRequestProperty("Accept", "text/html,application/xml,application/json;q=0.9,*/*;q=0.8");
            try {
                int code = c.getResponseCode();
                if (code >= 300 && code < 400) {
                    String loc = c.getHeaderField("Location");
                    if (loc == null) {
                        throw new IOException("Redirect without a location");
                    }
                    current = new URL(u, loc).toString();
                    continue;
                }
                InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
                Fetched f = new Fetched();
                f.status = code;
                f.finalUrl = current;
                f.data = in == null ? new byte[0] : readCapped(in, MAX_FETCH_BYTES);
                return f;
            } finally {
                c.disconnect();
            }
        }
        throw new IOException("Too many redirects");
    }

    // ---------------------------------------------------------------- JS bridge

    /** Exposed to the page as window.AndroidBridge (methods run on a background thread). */
    private class Bridge {

        @JavascriptInterface
        public boolean saveXmlFile(String filename, String content) {
            try {
                saveToDownloads(filename, content);
                return true;
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public boolean shareXmlFile(String filename, String content) {
            try {
                final Uri uri = saveToDownloads(filename, content);
                runOnUiThread(() -> {
                    Intent send = new Intent(Intent.ACTION_SEND);
                    send.setType("text/xml");
                    send.putExtra(Intent.EXTRA_STREAM, uri);
                    send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try {
                        startActivity(Intent.createChooser(send, "Send to Alight Motion"));
                    } catch (ActivityNotFoundException e) {
                        Toast.makeText(MainActivity.this, "Saved to Downloads/AlightFix", Toast.LENGTH_LONG).show();
                    }
                });
                return true;
            } catch (Exception e) {
                return false;
            }
        }

        /** Starts a chunked binary save. Images go to Pictures/AlightFix, everything else to Downloads/AlightFix. */
        @JavascriptInterface
        public String beginBinary(String filename, String mime) {
            try {
                boolean image = mime != null && mime.startsWith("image/");
                ContentValues values = new ContentValues();
                values.put(MediaStore.MediaColumns.DISPLAY_NAME, safeName(filename, "AlightFix.bin"));
                values.put(MediaStore.MediaColumns.MIME_TYPE, mime == null ? "application/octet-stream" : mime);
                values.put(MediaStore.MediaColumns.RELATIVE_PATH,
                        (image ? Environment.DIRECTORY_PICTURES : Environment.DIRECTORY_DOWNLOADS) + "/AlightFix");
                values.put(MediaStore.MediaColumns.IS_PENDING, 1);
                Uri collection = image ? MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                        : MediaStore.Downloads.EXTERNAL_CONTENT_URI;
                ContentResolver resolver = getContentResolver();
                Uri uri = resolver.insert(collection, values);
                if (uri == null) {
                    return "";
                }
                OutputStream out = resolver.openOutputStream(uri);
                if (out == null) {
                    resolver.delete(uri, null, null);
                    return "";
                }
                String id = Long.toString(System.nanoTime());
                synchronized (uploads) {
                    uploads.put(id, new Object[]{uri, out});
                }
                return id;
            } catch (Exception e) {
                return "";
            }
        }

        @JavascriptInterface
        public boolean appendBinary(String id, String base64Chunk) {
            Object[] u;
            synchronized (uploads) {
                u = uploads.get(id);
            }
            if (u == null) {
                return false;
            }
            try {
                ((OutputStream) u[1]).write(Base64.decode(base64Chunk, Base64.DEFAULT));
                return true;
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public boolean finishBinary(String id, boolean ok) {
            Object[] u;
            synchronized (uploads) {
                u = uploads.remove(id);
            }
            if (u == null) {
                return false;
            }
            Uri uri = (Uri) u[0];
            ContentResolver resolver = getContentResolver();
            boolean success = ok;
            try {
                ((OutputStream) u[1]).close();
            } catch (IOException e) {
                success = false;
            }
            if (success) {
                ContentValues done = new ContentValues();
                done.put(MediaStore.MediaColumns.IS_PENDING, 0);
                resolver.update(uri, done, null, null);
                return true;
            }
            resolver.delete(uri, null, null);
            return false;
        }

        /** Downloads a https page or file and hands it back to window.__fetchDone(id, status, url, base64, error). */
        @JavascriptInterface
        public void fetchUrl(final String id, final String url) {
            new Thread(() -> {
                int status = 0;
                String finalUrl = url;
                String b64 = "";
                String err = "";
                try {
                    Fetched f = fetch(url);
                    status = f.status;
                    finalUrl = f.finalUrl;
                    b64 = Base64.encodeToString(f.data, Base64.NO_WRAP);
                } catch (Exception e) {
                    err = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
                }
                final String js = "window.__fetchDone(" + JSONObject.quote(id) + "," + status + ","
                        + JSONObject.quote(finalUrl) + "," + JSONObject.quote(b64) + "," + JSONObject.quote(err) + ")";
                runOnUiThread(() -> {
                    if (webView != null) {
                        webView.evaluateJavascript(js, null);
                    }
                });
            }).start();
        }

        @JavascriptInterface
        public String getClipboardText() {
            try {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm == null || !cm.hasPrimaryClip()) {
                    return "";
                }
                ClipData d = cm.getPrimaryClip();
                if (d == null || d.getItemCount() == 0) {
                    return "";
                }
                CharSequence t = d.getItemAt(0).coerceToText(MainActivity.this);
                return t == null ? "" : t.toString();
            } catch (Exception e) {
                return "";
            }
        }

        @JavascriptInterface
        public boolean setClipboardText(final String text) {
            runOnUiThread(() -> {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm != null) {
                    cm.setPrimaryClip(ClipData.newPlainText("AlightFix", text));
                }
            });
            return true;
        }
    }
}
