# AlightFix Studio (Android)

One WebView app containing the full AlightFix Studio UI (Link Doctor, XML Sanitizer, Preset Generator,
Presets Vault, QR Studio, Guide) plus the Extreme Repair Engine as its own "Extreme Fix" tab and as an
optional checkbox inside the XML Sanitizer.

## Get an APK without a PC (GitHub Actions)
1. Create a new GitHub repo and upload everything in this folder (keep the `.github` folder).
2. Open the repo's Actions tab, run "Build APK" (it also runs on every push).
3. When it finishes, download the `AlightFixStudio-APK` artifact, unzip it, install `app-debug.apk`.
   Android will ask you to allow installs from your browser or file manager.

## Get an APK with Android Studio
Open this folder as a project. If Studio complains about a missing Gradle wrapper, choose Gradle 8.7 and JDK 17.
Then Build > Build APK(s). Output: app/build/outputs/apk/debug/app-debug.apk

## Notes
- Needs Android 10+ (minSdk 29). Saved files go to Downloads/AlightFix.
- The UI loads Tailwind, Font Awesome and a QR library from CDNs, so the app needs internet.
- Not built or run in the environment that produced it; if the build fails, send the first error line.
