# AlightFix Studio v3 (Android)

One WebView app: Link Doctor + "Get XML from link", Preset Finder, Extreme Fix (with frame-rate override),
XML Editor, Media tools (image upscaler, dead frame finder), Preset Generator (30/60/120 FPS), Vault, QR Studio,
Guide and a Style tab (liquid glass, custom colours).

## Build with GitHub Actions (no PC)
1. In your repo, replace `AlightFixStudio_Android.zip` with the new zip (same file name).
2. Actions tab > Build APK > Run workflow.
3. Download the `AlightFixStudio-APK` artifact, unzip, install `app-debug.apk`.
   If Android refuses to install over an older build, uninstall the old one first (each cloud build is signed with a new debug key).

## Build with Android Studio
Open this folder. If asked, use Gradle 8.7 and JDK 17. Build > Build APK(s).

## Notes
- Android 10+ (minSdk 29). Files go to Downloads/AlightFix, images to Pictures/AlightFix.
- Needs internet: the UI loads Tailwind, Font Awesome and a QR library from CDNs, and link features download files.
- Generated/Vault files use the real Alight Motion structure (taken from an exported project): scene header + rectangle shape layers with location/scale keyframes. Colour grading and text presets are disabled until real effect/text XML is available.
- Share links or .xml files to "AlightFix Studio" from other apps.
- Not compiled or run in the environment that produced it.
